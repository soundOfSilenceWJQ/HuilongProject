# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.
"""
The difference between me and the scripts in examples/benchmarks/benchmarks_dynamic
- This module only focus provide a general rolling implementation.
  Anything specific that benchmark is placed in examples/benchmarks/benchmarks_dynamic
"""
